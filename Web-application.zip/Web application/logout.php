<?php
error_reporting(E_ALL); ini_set('display_errors', '1'); 
session_start();
//unsets the session
session_unset();
//destroys the session
session_destroy();
//redirects to the main page
header ("Location: index.html"); 
exit;
?>
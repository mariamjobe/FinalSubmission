<?php
// starts the session to be able to access the session variables
session_start();
// creates the database connection
include("test.php");

// stores the user input in variables
$companyname = $_POST['companyname'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$username = $_POST['username'];
$password = $_POST['password'];

//checks if the username is taken
if(isset($_POST['submit'])){
	$sql = "SELECT Username from Company where Username = '".$username."'";
	$result = mysql_query($sql);
	if (mysql_num_rows($result) > 0){
		header("Refresh: 0; url=companysignup.php");
        $message = 'Username is allready taken.';

		echo "<SCRIPT>
		alert('$message');
		</SCRIPT>";


	}
else{
//inserts the new company into database
mysql_query("INSERT INTO Company SET Companyname='".$companyname."',name='".$name."', Company_Phone='".$phone."', Username='".$username."', 
            Password='".$password."'") or die(mysql_error());
   header("Refresh: 0; url=index.html");
                 $message = 'You have succesfully signed up!';

echo "<SCRIPT>
alert('$message');
</SCRIPT>";


}
}

?>
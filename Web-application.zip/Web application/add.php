<?php
session_start();
// creates connection to database
include 'test.php';

//takes input from driverTable.php and stores in variables
$name = $_POST['name'];
$phnumber = $_POST['phone'];
$driverusername = $_POST['username'];
$password = $_POST['password'];


//checks if the username is already in the database

	if(isset($_POST['username'])){
		$result = mysql_query("SELECT username from Employee where Username = '".$driverusername."'"); 
		$row = mysql_fetch_row($result);
		if($row > 0){
				header("Refresh: 0; url=driverTable.php");

				// a popup message using javascript
				$message = 'Username is allready taken.';
				echo "<SCRIPT>
				alert('$message');
				</SCRIPT>";
            
		}
// checks if the username and password is equal
if($row == 0){
	if($driverusername != $password){ 
		header("Refresh: 0; url=driverTable.php");
		$message = 'Password and username are not equal! Enter the same value for username and password please.';

echo "<SCRIPT>
alert('$message');
</SCRIPT>";

	}
	else{

	//queries the database with an insert statement that adds a new employee
	mysql_query ("INSERT INTO Employee SET  CompanyId='".$_SESSION['CompanyId']."',name='".$name."', Phone='".$phnumber."', Username='".$driverusername."', Password='".$password."'") or die(mysql_error()); //after checking other cases, we are finally inserting the employee to the database.
	$r =mysql_affected_rows ();
	if($r > 0) {
	header("Refresh: 0; url=driverTable.php");

	// a popup message using javascript
	$message = 'Employee added.';
	echo "<SCRIPT>
	alert('$message');
	</SCRIPT>";
}
}
}

}


?>
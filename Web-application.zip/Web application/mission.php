<?php
error_reporting(E_ERROR | E_PARSE);
// starts the session to be able to access the session variables
session_start();
//database connection
include("test.php");

//stores the user input into variables
$Mission_Name = $_POST['Mission_Name'];
$CompanyID = $_SESSION['CompanyId'];
$name = $_POST["dropdown"];
$Customer_Phone = $_POST['Customer_Phone'];
$Address = $_POST['Address'];
$ZipCode = $_POST['ZipCode'];
$City = $_POST['City'];
$Country = $_POST['Country'];

// checks if some input field hasn't been filled when submit is clicked
if(!$_POST['submit']){
	echo "Fill in everything";
}else{

    //gets the employee id and stores it in a session variable
$getID = ("Select Employee_Id from Employee where Name = '".$name."'");
$results = mysql_query($getID) or die('Query faild: '. mysql_error());
	while ($row =mysql_fetch_array($results,MYSQL_ASSOC)){
		echo "<tr>\n";
		foreach ($row as $col_value){
    $id = mysql_free_result($results);
	$_SESSION['Employee_ID'] = $col_value;
	}
    }

    // adds a mission to the database with the user input variables
	mysql_query("INSERT INTO Missions SET Mission_Name='".$Mission_Name."',Employee_Name = '".$name."',CompanyID='".$_SESSION['CompanyId']."', Employee_ID='".$_SESSION['Employee_ID']."', Customer_Phone='".$Customer_Phone."', 
            Address='".$Address."',ZipCode='".$ZipCode."', City='".$City."',Country='".$Country."'");
		
	$r=mysql_affected_rows();
	if($r>0){
		 header("Refresh: 0; url=table.php");
		 // popup message in javascript
		$message = 'Mission added successfully!';
		echo "<SCRIPT>
		alert('$message');
		</SCRIPT>";	
	}else {
			 header("Refresh: 0; url=table.php");
			 $message2 = 'Mission has NOT been added, please try again!';
			 echo "<SCRIPT>
			 alert('$message2');
			</SCRIPT>";	
	}
}

?>
package com.example.mariam.miswa;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;


public class MainActivity extends ActionBarActivity {
    //Declare Variable
    private static EditText username;
    private static EditText password;
    private static Button loginbtn;
    String Username;
    String Password;

    //id1= employee id && id2 = company id
    String id1 = "" ;
    String id2 = "" ;

    //adding ripple effects to button
    private AlphaAnimation buttonClick = new AlphaAnimation(1F, 0.3F);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loginButton();
    }

    //action performed on click of login button
    public void loginButton(){
        username = (EditText) findViewById(R.id.editText_username);
        password = (EditText) findViewById(R.id.editText_password);
        loginbtn = ( Button ) findViewById(R.id.button_login);

        loginbtn.setOnClickListener(

                new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {

                        //show ripple effect when button is clicked
                        view.startAnimation(buttonClick);

                        //get value of username and password from text fields
                        Username = username.getText().toString();
                        Password = password.getText().toString();

                        tryLogin(Username, Password);
                    }
                });
    }

    //method handling the log in
    protected void tryLogin(String Username, String Password) {

        //get values from text fields
        String UserName = username.getText(). toString();
        String PassWord = password.getText(). toString();

        //build the http connection
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        HttpURLConnection connection;
        OutputStreamWriter request = null;

        URL url = null;
        String response = null;
        String parameters = "username="+ Username +"&password="+ Password ;

        try
        {
            //get response from the url for every login action
            url = new URL("http://apps.dev01.luqon.com/appui/api/login.php");
            connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestMethod("POST");

            request = new OutputStreamWriter(connection.getOutputStream());
            request.write(parameters);
            request.flush();
            request.close();
            String line = "";
            InputStreamReader isr = new InputStreamReader(connection.getInputStream());
            BufferedReader reader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();

            //url gives true and false values depending on values inserted for login
            String output = "false";
            while ((line = reader.readLine()) != null)
            {
                sb.append(line);
                output = line;
            }

            //case 1:  when username and password are correct and are not similar
            if( !(UserName .equals(PassWord) ) && output.toLowerCase().contains("true") ) {
                Toast.makeText(MainActivity.this, "username and password is correct", Toast.LENGTH_LONG).show();

                //get id1 and id2 from jsonArray from url based on the username and password entered
                JSONObject jsonobject = JSONfunctions.getJSONfromURL("http://apps.dev01.luqon.com/appui/api/getIds.php?"+parameters);
                try {
                    // Locate the array name in JSON
                    JSONArray jsonarray = jsonobject.getJSONArray("data");
                    for (int i = 0; i < jsonarray.length(); i++) {
                        jsonobject = jsonarray.getJSONObject(i);

                        //get values from json array
                        id1=jsonobject.getString("Employee_Id");
                        id2=jsonobject.getString("CompanyId");
                    }

                } catch (JSONException e) {
                    Log.e("Error", e.getMessage());
                    e.printStackTrace();
                }

                //Move to next avtivity (welcome page )
                Intent intent1 = new Intent(MainActivity.this, UserActivity.class);

                //pass values for employee id and customer id.
                intent1.putExtra ( "employeeid", id1 );
                intent1.putExtra ( "companyid" , id2 );

                startActivity(intent1);
            }

            // case 2: username and password are correct and are similar
            else if((UserName.equals(PassWord) ) && output.toLowerCase().contains("true")) {
                Toast.makeText(MainActivity.this, "Password Needs To Be Changed", Toast.LENGTH_LONG).show();

                JSONObject jsonobject = JSONfunctions.getJSONfromURL("http://apps.dev01.luqon.com/appui/api/getIds.php?"+parameters);
                try {
                    // Locate the array name in JSON
                    JSONArray jsonarray = jsonobject.getJSONArray("data");
                    for (int i = 0; i < jsonarray.length(); i++) {
                        jsonobject = jsonarray.getJSONObject(i);
                        //get values from json array
                        id1=jsonobject.getString("Employee_Id");
                        id2=jsonobject.getString("CompanyId");
                    }

                } catch (JSONException e) {
                    Log.e("Error", e.getMessage());
                    e.printStackTrace();
                }

                //Move to next avtivity (change password)
                Intent intent = new Intent(MainActivity.this, ChangePassword.class);

                //pass values for employee id, customer id an username.
                intent.putExtra ( "Username", username.getText().toString() );
                intent.putExtra ( "companyid" , id2 );
                intent.putExtra ( "employeeid", id1 );

                startActivity(intent);
            }

            //case 3: username and password are not correct
            else {
                Toast.makeText(MainActivity.this, "username or password is incorrect", Toast.LENGTH_LONG).show();
            }

            isr.close();
            reader.close();
        }
        catch(IOException e){
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}

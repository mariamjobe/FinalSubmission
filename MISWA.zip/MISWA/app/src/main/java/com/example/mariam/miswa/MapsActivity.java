package com.example.mariam.miswa;


import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.StrictMode;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.swedspot.automotiveapi.AutomotiveSignal;
import android.swedspot.automotiveapi.AutomotiveSignalId;
import android.swedspot.scs.data.Uint8;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.swedspot.automotiveapi.AutomotiveFactory;
import com.swedspot.automotiveapi.AutomotiveListener;
import com.swedspot.vil.distraction.DriverDistractionLevel;
import com.swedspot.vil.distraction.DriverDistractionListener;
import com.swedspot.vil.distraction.LightMode;
import com.swedspot.vil.distraction.StealthMode;
import com.swedspot.vil.policy.AutomotiveCertificate;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class MapsActivity extends FragmentActivity implements LocationListener {
    //Declare variables
    int brake;
    String customer = "";
    String company = "";
    private static Button CallCustomer;
    private static Button CallCompany;
    ArrayList<LatLng> markerPoints;
    GoogleMap googleMap;
    double mLatitude=0;
    double mLongitude=0;
    Location location;

    Context context;
    ArrayList<HashMap<String, String>> arraylist;
    Geocoder geocoder = new Geocoder(this, Locale.getDefault());

    //getting values from ListViewAdapter
    ListViewAdapterM LVAM = new ListViewAdapterM(context, arraylist);
    String name = "";
    String addresses = "";
    String id1 = LVAM.id1;
    String id2 = LVAM.id2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        //get values from previous activity
        Intent i = getIntent();
        name = i.getStringExtra("name");
        addresses = i.getStringExtra("addresses");

        //finish activity if GPS is not available
        if (!isGooglePlayServicesAvailable()) {
            finish();
        }

        int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getBaseContext());

        if (status != ConnectionResult.SUCCESS) { // Google Play Services are not available
            int requestCode = 10;
            Dialog dialog = GooglePlayServicesUtil.getErrorDialog(status, this, requestCode);
            dialog.show();

        } else { // Google Play Services are available
            // Initializing
            markerPoints = new ArrayList<LatLng>();

            // Getting reference to SupportMapFragment of the activity_main
            SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
            googleMap = supportMapFragment.getMap();
            googleMap.setMyLocationEnabled(true);

            // Getting LocationManager object from System Service LOCATION_SERVICE
            final LocationManager locationManager = (LocationManager) getSystemService(context.LOCATION_SERVICE);
            // Creating a criteria object to retrieve provider
            final Criteria criteria = new Criteria();
            // Getting the name of the best provider
            final String bestProvider = locationManager.getBestProvider(criteria, true);
            // Getting Current Location From GPS
            location = locationManager.getLastKnownLocation(bestProvider);

            if (location != null) {
                onLocationChanged(location);
            }

            locationManager.requestLocationUpdates(bestProvider, 20000, 0, this);

            if (location == null) {

                //show error message it app does not find location
                final Toast toast = new Toast(getApplicationContext());
                toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                toast.setDuration(Toast.LENGTH_LONG);
                TextView txt1 = new TextView(this);
                txt1.setText("No Network Found!! Turn On your GPS And/Or ReStart The App!!");
                txt1.setTextSize(30);
                txt1.setTextColor(Color.BLACK);
                toast.setView(txt1);
                toast.show();

                //show message for 10 seconds
                new CountDownTimer(9000, 1000)
                {
                    public void onTick(long millisUntilFinished) {toast.show();}
                    public void onFinish() {toast.show();}

                }.start();

            } else {

                //get latitude and longitude for current location
                double latitude1  = location.getLatitude();
                double longitude1 = location.getLongitude();
                final LatLng location1 = new LatLng(latitude1, longitude1);

                String Place2;
                Place2 = addresses;
                final View mapView;

                try {
                    List<Address> addresses = geocoder.getFromLocationName(Place2, 5);
                    Address address = addresses.get(0);

                        //get latitude and longitude of final destination
                        double longitude2 = address.getLongitude();
                        double latitude2 = address.getLatitude();
                        final LatLng location2 = new LatLng(latitude2, longitude2);
                        System.out.println(location2);

                        //adding marker points to location1 and location3
                        markerPoints.add(1, location1);
                        markerPoints.add(2, location2);

                        FragmentManager fm = getSupportFragmentManager();
                        // Already map contain destination location
                        if (markerPoints.size() > 1) {
                            markerPoints.clear();
                            googleMap.clear();
                            drawMarker(location1);
                            drawMarker(location2);
                        }

                        if (markerPoints.size() >= 2) {

                            LatLng origin = markerPoints.get(0);
                            LatLng dest = markerPoints.get(1);

                            String url = getDirectionsUrl(origin, dest);
                            DownloadTask downloadTask = new DownloadTask();
                            downloadTask.execute(url);
                        }


                        //show maximum zoom between two points
                        final LatLngBounds.Builder builder = new LatLngBounds.Builder();
                        builder.include(location1);
                        builder.include(location2);

                        CameraUpdate cameraUpdate = CameraUpdateFactory
                                .newLatLngBounds(builder.build(), 10);


                        googleMap.setOnCameraChangeListener(new GoogleMap.OnCameraChangeListener() {

                            @Override
                            public void onCameraChange(CameraPosition arg0) {
                                // Move camera.
                                googleMap.moveCamera(CameraUpdateFactory.newLatLngBounds(builder.build(), 10));
                                // Remove listener to prevent position reset on camera move.
                                googleMap.setOnCameraChangeListener(null);
                            }
                        });

                    }catch(IOException e){
                        e.printStackTrace();
                    }
                }
        }

        new AsyncTask() {

            @Override
            protected Object doInBackground(Object... objects) {
                AutomotiveFactory.createAutomotiveManagerInstance(
                        new AutomotiveCertificate(new byte[0]),
                        new AutomotiveListener() {
                            @Override
                            public void receive(final AutomotiveSignal automotiveSignal) {

                                //get value of brake from the simulator
                                brake = ((Uint8) automotiveSignal.getData()).getByteValue();
                                if (brake == 1) {
                                    Intent intent = new Intent(MapsActivity.this, MissionList.class);

                                    //pass values in the next activity
                                    intent.putExtra ( "employeeid", id1 );
                                    intent.putExtra ( "companyid" , id2 );

                                    startActivity(intent);
                                    finish();
                                }
                            }
                            @Override
                            public void timeout(int i) {

                            }
                            @Override
                            public void notAllowed(int i) {
                            }
                        },

                       new DriverDistractionListener() {
                            @Override
                            public void levelChanged(final DriverDistractionLevel driverDistractionLevel) {

                            }

                            @Override
                            public void lightModeChanged(LightMode lightMode) {

                            }

                            @Override
                            public void stealthModeChanged(StealthMode stealthMode) {

                            }
                        }
                ).register(AutomotiveSignalId.FMS_PARKING_BRAKE);// AutomotiveSignalId.FMS_CURRENT_GEAR
                return null;
            }
        }.execute();

        //calling functions in on create method
        CustomerContact();
        CompanyContact();

        Customer();
        Company();
    }

    private String getDirectionsUrl(LatLng origin, LatLng dest) {

        // Origin of route
        String str_origin = "origin=" + origin.latitude + "," + origin.longitude;

        // Destination of route
        String str_dest = "destination=" + dest.latitude + "," + dest.longitude;

        // Sensor enabled
        String sensor = "sensor=false";

        // Building the parameters to the web service
        String parameters = str_origin + "&" + str_dest + "&" + sensor;

        // Output format
        String output = "json";

        String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters;

        return url;
    }

    private String downloadUrl(String strUrl) throws IOException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(strUrl);

            // Creating an http connection to communicate with url
            urlConnection = (HttpURLConnection) url.openConnection();

            // Connecting to url
            urlConnection.connect();

            // Reading data from url
            iStream = urlConnection.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));
            StringBuffer sb = new StringBuffer();
            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            data = sb.toString();

            br.close();

        } catch (Exception e) {

        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

    /** A class to download data from Google Directions URL */
    private class DownloadTask extends AsyncTask<String, Void, String> {
        // Downloading data in non-ui thread
        @Override
        protected String doInBackground(String... url) {
            // For storing data from web service
            String data = "";
            try {
                // Fetching the data from web service
                data = downloadUrl(url[0]);
            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        // Executes in UI thread, after the execution of
        // doInBackground()
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            ParserTask parserTask = new ParserTask();

            // Invokes the thread for parsing the JSON data
            parserTask.execute(result);
        }
    }


    private class ParserTask extends AsyncTask<String, Integer, List<List<HashMap<String, String>>>> {
        // Parsing the data in non-ui thread
        @Override
        protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {

            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;

            try {
                jObject = new JSONObject(jsonData[0]);
                DirectionsJSONParser parser = new DirectionsJSONParser();

                // Starts parsing data
                routes = parser.parse(jObject);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return routes;
        }

        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> result) {
            ArrayList<LatLng> points = null;
            PolylineOptions lineOptions = null;

            // Traversing through all the routes
            for (int i = 0; i < result.size(); i++) {
                points = new ArrayList<LatLng>();
                lineOptions = new PolylineOptions();

                // Fetching i-th route
                List<HashMap<String, String>> path = result.get(i);

                // Fetching all the points in i-th route
                for (int j = 0; j < path.size(); j++) {
                    HashMap<String, String> point = path.get(j);

                    double lat = Double.parseDouble(point.get("lat"));
                    double lng = Double.parseDouble(point.get("lng"));
                    LatLng position = new LatLng(lat, lng);

                    points.add(position);
                }
                // Adding all the points in the route to LineOptions
                lineOptions.addAll(points);
                lineOptions.width(10);
                lineOptions.color(Color.RED);
            }
            // Drawing polyline in the Google Map for the i-th route
            googleMap.addPolyline(lineOptions);
        }
    }

    //@Override
   /* public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu_maps, menu);
        return true;
    }*/

    private void drawMarker(LatLng point){
        markerPoints.add(point);

        // Creating MarkerOptions
        MarkerOptions options = new MarkerOptions();

        // Setting the position of the marker
        options.position(point);

         // For the start location, the color of marker is GREEN and
         //for the end location, the color of marker is RED.
        if(markerPoints.size()==1){
            options.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
        }else if(markerPoints.size()==2){
            options.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
        }
        // Add new marker to the Google Map Android API V2
        googleMap.addMarker(options);
    }

    @Override
    public void onLocationChanged(Location location) {
    // Draw the marker, if destination location is not set
        if (markerPoints.size() < 2) {
            mLatitude = location.getLatitude();
            mLongitude = location.getLongitude();
            LatLng point = new LatLng(mLatitude, mLongitude);

            googleMap.moveCamera(CameraUpdateFactory.newLatLng(point));
            googleMap.animateCamera(CameraUpdateFactory.zoomTo(12));

            drawMarker(point);
        }
    }

    @Override
    public void onProviderDisabled(String provider) {
        // TODO Auto-generated method stub
    }

    @Override
    public void onProviderEnabled(String provider) {
        // TODO Auto-generated method stub
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // TODO Auto-generated method stub
    }



    // getting the customer phone number from jsonarray from a url
    public void CustomerContact() {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        HttpURLConnection connection;
        OutputStreamWriter request = null;

        URL url = null;
        String response = null;
        String parameters = "id=" + id1 + "&id2=" + id2 + "&name=" + name;

        try {
            //building connection with the url
            url = new URL("http://apps.dev01.luqon.com/appui/api/ContactCustomer.php");
            connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestMethod("POST");

            request = new OutputStreamWriter(connection.getOutputStream());
            request.write(parameters);
            request.flush();
            request.close();
            String line = "";
            InputStreamReader isr = new InputStreamReader(connection.getInputStream());
            BufferedReader reader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String output = "false";
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                output = line;
                System.out.println(output + "hh");
            }

            JSONObject jsonobject;
            JSONArray jsonarray;

            jsonobject = JSONfunctions
                    .getJSONfromURL("http://apps.dev01.luqon.com/appui/api/ContactCustomer.php?" + parameters);

            try {
                // Locate the array name in JSON
                jsonarray = jsonobject.getJSONArray("contacts");

                for (int i = 0; i < jsonarray.length(); i++) {
                    HashMap<String, String> CusContact = new HashMap<String, String>();
                    jsonobject = jsonarray.getJSONObject(i);

                    // Retrive JSON Object
                    customer = jsonobject.getString("Customer_Phone");
                }
            } catch (JSONException e) {

            }
            //store value of phone number in a variable
            customer = jsonobject.getString("Customer_Phone");

        } catch (Exception e) {

        }
    }

    // getting the customer phone number from jsonarray from a url
    public void CompanyContact() {

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        HttpURLConnection connection;
        OutputStreamWriter request = null;

        URL url = null;
        String response = null;
        String parameters = "id=" + id2;

        try {
            //building connection with the url
            url = new URL("http://apps.dev01.luqon.com/appui/api/ContactCompany.php");
            connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestMethod("POST");


            request = new OutputStreamWriter(connection.getOutputStream());
            request.write(parameters);
            request.flush();
            request.close();
            String line = "";
            InputStreamReader isr = new InputStreamReader(connection.getInputStream());
            BufferedReader reader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String output = "false";
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                output = line;
            }

            JSONObject jsonobject;
            JSONArray jsonarray;

            jsonobject = JSONfunctions
                    .getJSONfromURL("http://apps.dev01.luqon.com/appui/api/ContactCompany.php?" + parameters);

            try {
                // Locate the array name in JSON
                jsonarray = jsonobject.getJSONArray("contacts");


                for (int i = 0; i < jsonarray.length(); i++) {
                    HashMap<String, String> CusContact = new HashMap<String, String>();
                    jsonobject = jsonarray.getJSONObject(i);
                    // Retrive JSON Objects
                    company = jsonobject.getString("Company_Phone");
                }
            } catch (JSONException e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            //store value of phone number in a variable
            company = jsonobject.getString("Company_Phone");

        } catch (Exception e) {

        }
    }

    //call customer on button click
    public void Customer() {
        CallCustomer = (Button) findViewById(R.id.btn_customer);

        CallCustomer.setOnClickListener(
            new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Intent.ACTION_DIAL);
                    String p = "tel:" + customer.toString();
                    i.setData(Uri.parse(p));
                    startActivity(i);
                }
            });
    }

    //call company on button click
    public void Company() {
        CallCompany = (Button) findViewById(R.id.btn_company);

        CallCompany.setOnClickListener(
            new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Intent.ACTION_DIAL);
                    String p = "tel:" + company.toString();
                    i.setData(Uri.parse(p));
                    startActivity(i);

                }
            });
    }

    //getting google play availability status
    private boolean isGooglePlayServicesAvailable() {
        int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (ConnectionResult.SUCCESS == status) {
            return true;
        } else {
            GooglePlayServicesUtil.getErrorDialog(status, this, 0).show();
            return false;
        }
    }

}































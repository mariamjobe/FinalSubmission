package com.example.mariam.miswa;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.swedspot.automotiveapi.AutomotiveSignal;
import android.swedspot.automotiveapi.AutomotiveSignalId;
import android.swedspot.scs.data.SCSFloat;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.TextView;
import com.swedspot.automotiveapi.AutomotiveFactory;
import com.swedspot.automotiveapi.AutomotiveListener;
import com.swedspot.vil.distraction.DriverDistractionLevel;
import com.swedspot.vil.distraction.DriverDistractionListener;
import com.swedspot.vil.distraction.LightMode;
import com.swedspot.vil.distraction.StealthMode;
import com.swedspot.vil.policy.AutomotiveCertificate;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;

public class MissionList extends ActionBarActivity {

    //Declare Variables
    public static boolean clicked = false;
    public static boolean done = false;
    public static String name1= "" ;
    public static String addresses1 = "";
    public static String id1 = "";
    public static String id2 = "";
    static String NAME = "Name1";
    static String ADDRESS = "Address1";
    static String CITY = "City";
    static String COUNTRY = "Country";
    double speed;

    ArrayList<HashMap<String, String>> arraylist;
    static Context context;


    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mission_list);

        //getting values from the previous activity
        Intent in = getIntent();
        id1 = in.getStringExtra ( "employeeid" );
        id2 = in.getStringExtra ( "companyid" );

        new DownloadJSON1().execute();

        new AsyncTask() {

            @Override
            protected Object doInBackground(Object... objects) {
                AutomotiveFactory.createAutomotiveManagerInstance(
                        new AutomotiveCertificate(new byte[0]),
                        new AutomotiveListener() {
                            @Override
                            public void receive(final AutomotiveSignal automotiveSignal) {
                                //get the value of speed from the simulator
                                speed = ((SCSFloat) automotiveSignal.getData()).getFloatValue();

                                //clicked is used for the item  clicked, and done is used
                                // when screen is changed from mission list to maps activity
                                if (clicked == true && speed >= 0.1 && done == false) {

                                    //starting the new activity
                                    Intent intent = new Intent(context, MapsActivity.class);
                                    done = true;

                                    //passing values in the next avtivity(MapsActivity)
                                    intent.putExtra("name", name1);
                                    intent.putExtra("addresses", addresses1);
                                    intent.putExtra("employeeid", id1);
                                    intent.putExtra("companyid", id2);

                                    context.startActivity(intent);

                                }
                            }

                            @Override
                            public void timeout(int i) {

                            }

                            @Override
                            public void notAllowed(int i) {

                            }
                        },

                        new DriverDistractionListener() {
                            @Override
                            public void levelChanged(final DriverDistractionLevel driverDistractionLevel) {

                            }

                            @Override
                            public void lightModeChanged(LightMode lightMode) {

                            }

                            @Override
                            public void stealthModeChanged(StealthMode stealthMode) {

                            }
                        }
                ).register(AutomotiveSignalId.FMS_WHEEL_BASED_SPEED);
                return null;
            }
        }.execute();

    }


    // DownloadJSON AsyncTask
    private class DownloadJSON1 extends AsyncTask<Void, Void, Void> {

        //Decalare Variables
        ListView listview1;
        ListViewAdapterM adapter;
        ProgressDialog mProgressDialog;
        ArrayList<HashMap<String, String>> arraylist;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Create a progressdialog
            mProgressDialog = new ProgressDialog(MissionList.this);
            // Set progressdialog title
            mProgressDialog.setTitle("Missions");
            // Set progressdialog message
            mProgressDialog.setMessage("Loading...");
            mProgressDialog.setIndeterminate(false);
            // Show progressdialog
            mProgressDialog.show();
        }

        protected Void doInBackground(Void... params) {
            //get values of variables from previous activity
            Intent in = getIntent();
            id1 = in.getStringExtra("employeeid");
            id2 = in.getStringExtra("companyid");

            JSONObject jsonobject1;
            JSONArray  jsonarray1;

            // Create an array
            arraylist = new ArrayList<HashMap<String, String>>();
            // Retrieve JSON Objects from the given URL address
            jsonobject1 = JSONfunctions
                    .getJSONfromURL("http://apps.dev01.luqon.com/appui/api/missions.php?id=" + id1 + "&id2=" + id2);

            try {
                // Locate the array name in JSON
                jsonarray1 = jsonobject1.getJSONArray("missions");

                if (jsonarray1.length() == 0){
                //display message when there are no mission to display in the the list view
                listview1 = (ListView) findViewById(R.id.listview1);
                listview1.setAdapter(adapter);
                listview1.setEmptyView(findViewById(R.id.emptyElement));

            }else {

                    //Diplay all the missions in the listview retrieved from the database
                    for (int i = 0; i < jsonarray1.length(); i++) {
                        HashMap<String, String> missionlist = new HashMap<String, String>();

                        jsonobject1 = jsonarray1.getJSONObject(i);

                        // Retrive JSON Objects
                        missionlist.put("Name1", jsonobject1.getString("Mission_Name"));

                        missionlist.put("Address1", jsonobject1.getString("Address"));

                        missionlist.put("City", jsonobject1.getString("City"));

                        missionlist.put("Country", jsonobject1.getString("Country"));

                        // Set the JSON Objects into the array
                        arraylist.add(missionlist);
                    }

                }
            }catch(JSONException e){
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return null;

        }

        @Override
        protected void onPostExecute(Void args) {
            ArrayList<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();

            // Locate the listview in listview_main.xml
            listview1 = (ListView) findViewById(R.id.listview1);
            // Pass the results into ListViewAdapter.java
            adapter = new ListViewAdapterM(MissionList.this, arraylist);

            // Set the adapter to the ListView
            listview1.setAdapter(adapter);
            // Close the progressdialog
            mProgressDialog.dismiss();
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_mission_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}

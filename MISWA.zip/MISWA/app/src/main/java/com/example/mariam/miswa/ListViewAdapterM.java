package com.example.mariam.miswa;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;


public class ListViewAdapterM extends BaseAdapter {

    //Declare Variables
    private static TextView mission;
    private static TextView address;
    String name = "";
    String addresses = "";

    View itemView1 = null ;
    LayoutInflater inflater;
    ArrayList<HashMap<String, String>> data1;
    HashMap<String, String> resultp1 = new HashMap<String, String>();

    //Get values from mission list
    MissionList ML = new MissionList();
    String id1 = ML.id1;
    String id2 = ML.id2;

    public ListViewAdapterM(Context context, ArrayList<HashMap<String, String>> arraylist) {
        //set the context to context in mission list
        ML.context=context;
        data1 = arraylist;
    }

    @Override
    public int getCount() {
        return data1.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {

        inflater = (LayoutInflater) ML.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        itemView1 = inflater.inflate(R.layout.listview_itemm, parent, false);

        // Get the position
        resultp1 = data1.get(position);

        // Locate the TextViews in listview_itemm.xml
        mission = (TextView) itemView1.findViewById(R.id.textView_mission2);
        address = (TextView) itemView1.findViewById(R.id.textView_address2);

        // Capture position and set results to the TextViews
        mission.setText(resultp1.get(MissionList.NAME));
        address.setText(resultp1.get(MissionList.ADDRESS) +" "+ resultp1.get(MissionList.CITY) +" "+ resultp1.get(MissionList.COUNTRY));

        //set value in a variable
        name = resultp1.get(MissionList.NAME);
        addresses = resultp1.get(MissionList.ADDRESS) + resultp1.get(MissionList.CITY) + resultp1.get(MissionList.COUNTRY);

        // Capture ListView item click
        itemView1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                resultp1 = data1.get(position);
                //refresh value for name and address as the item clicked is changed
                name = resultp1.get(MissionList.NAME);
                addresses = resultp1.get(MissionList.ADDRESS) + " " + resultp1.get(MissionList.CITY) + " " + resultp1.get(MissionList.COUNTRY);

                //setting the values to variable in MissionList
                ML.name1 =  name;
                ML.addresses1 = addresses;
                ML.clicked = true;
                ML.done = false;

               //set colour of item clicked
               if (itemView1 != null)
               {
                   itemView1.setBackgroundColor(Color.parseColor("#A4A4A4"));
               }
               arg0.setBackgroundColor(Color.parseColor("#FFBF00"));

               itemView1 = arg0;
            }
        });
        return itemView1;
    }
}

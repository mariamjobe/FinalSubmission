package com.example.mariam.miswa;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class ChangePassword extends ActionBarActivity {

    //Declare Variables
    private static EditText password1;
    private static EditText password2;
    private static Button saveButton;
    String id1= "";
    String id2= "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        updatepassword();

        //get values for employee id and company id from the previous activity
        Intent i = getIntent();
        id1=  i.getStringExtra( "employeeid" );
        id2=  i.getStringExtra( "companyid" );
    }

    //action performed on button "SAVE" click
    public void updatepassword() {
        password1  = (EditText) findViewById(R.id.changepassword);
        password2  = (EditText) findViewById(R.id.confirmpassword);
        saveButton = ( Button ) findViewById(R.id.button_save);

        saveButton.setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        //get value entered in the two password fields
                        String Password1 = password1.getText().toString();
                        String Password2 = password2.getText().toString();

                        //get value of username from previous activity and store value of password1 in a variable
                        Intent i = getIntent();
                        String Username = i.getStringExtra ( "Username" );
                        String Password  = password1.getText().toString();

                        //case 1: password in both fields are same
                        if (Password1.equals(Password2)) {
                            Updating( Username,  Password );
                        //case 2: password in bith fields are different
                        }else{
                            Toast.makeText(ChangePassword.this, "Password in both fields should be identical", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    public void Updating( String Username, String Password ) {

        //case 3: password is equal to the username,
        //system will prompt to enter a unique password
        if(Username.equals(Password)){
            Toast.makeText(ChangePassword.this, "Password Should Be Unique", Toast.LENGTH_SHORT).show();
        } else {

            //case 4: new password is updated if password in both fields is identical
            // && password is not equal to the username
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            HttpURLConnection connection;
            OutputStreamWriter request = null;
            URL url = null;
            String response = null;
            String parameters = "username=" + Username +"&password=" + Password;

            try{
                url = new URL("http://apps.dev01.luqon.com/appui/api/ChangePassword.php");
                connection = (HttpURLConnection) url.openConnection();
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                connection.setRequestMethod("POST");

                request = new OutputStreamWriter(connection.getOutputStream());
                request.write(parameters);
                request.flush();
                request.close();
                String line = "";
                InputStreamReader isr = new InputStreamReader(connection.getInputStream());
                BufferedReader reader = new BufferedReader(isr);
                StringBuilder sb = new StringBuilder();
                String output = "false";
                while ((line = reader.readLine()) != null)
                {
                    sb.append(line);
                    output = line;
                }

                //when json result from the url gives true, it indicates password id updated
                if( output.toLowerCase().contains("true") ) {
                    Toast.makeText(ChangePassword.this,"Password Updated", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent (ChangePassword.this, UserActivity.class);

                    //pass value of employee and company id to the next activity
                    intent.putExtra("employeeid", id1);
                    intent.putExtra ("companyid" , id2 );

                    startActivity(intent);
                }

                //case when some error occur while updating the padssword in the database
                else {
                    Toast.makeText(ChangePassword.this, " Error Accured, Try Again !! ", Toast.LENGTH_SHORT).show();
                }
                // You can perform UI operations here
                //Toast.makeText(this,"Message from Server: \n"+ response, Toast.LENGTH_SHORT).show();
                isr.close();
                reader.close();

            }catch (Exception e){

            }
        }
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_change_password, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}


package com.example.mariam.miswa;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class UserActivity extends ActionBarActivity {

    //Declare Variable
    private static Button missions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        MissionList();
    }

    //method calling the next activity
    public void MissionList(){
        missions=(Button) findViewById(R.id.button_gps);

        missions.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //move to next activity (mission list)
                        Intent myIntent = new Intent(UserActivity.this, MissionList.class);

                        //get values for employee id and company id from the previous activity
                        Intent in = getIntent();
                        String id1 = in.getStringExtra ( "employeeid" );
                        String id2 = in.getStringExtra ( "companyid" );

                        //pass values of employee id and company id in the next avtivity
                        myIntent.putExtra ( "employeeid", id1 );
                        myIntent.putExtra ( "companyid" , id2 );

                        UserActivity.this.startActivity(myIntent);
                    }
                });
        }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_user, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

